import React, { useState } from 'react';
import axios from 'axios';


export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');


  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await axios.post('https://localhost:7007', {
        email: email,
        password: password,
      });

     
      if (response.status === 200) {
        localStorage.setItem('token', response.data.token); 
        history.push('/dashboard'); 
      }
    } catch (err) {
      setError('hibás email vagy jelszó!'); 
    }
  };

  return (
    <div className="login-container">
      <h2>Bejelentkezés</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            required
          />
        </div>
        <div className="form-group">
          <label>Jelszó</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Jelszó"
            required
          />
        </div>
        {error && <p className="error">{error}</p>}
        <button type="submit">Bejelentkezés</button>
      </form>
    </div>
  );
}
