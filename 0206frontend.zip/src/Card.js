import React from 'react';
import { Link } from 'react-router-dom';

export default function Card({ hirdetes }) {
  return (
    <div className="card" style={{ width: '18rem' }}>
      <img className="card-img-top" src={hirdetes.kepURL || './házikó.png'} alt="Hirdetés" />
      <div className="card-body">
        <h5 className="card-title">Eladó Lakás {hirdetes.id}</h5>
        <p className="card-text">{hirdetes.leiras || 'Csendes környéken található lakás, közel a közlekedéshez.'}</p>
        <Link to={`/hirdetes/${hirdetes.id}`} className="btn btn-primary">
          Részletek <i className="bi bi-info-circle-fill"></i>
        </Link>
      </div>
    </div>
  );
}