import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Card from './Card';

export default function Home() {
    const [hirdetesek, setHirdetesek] = useState([]);

    useEffect(() => {
        // Hirdetések lekérése a backendről
        axios.get('https://localhost:7007')
            .then(response => {
                console.log(response.data);
                setHirdetesek(response.data);
            })
            .catch(error => {
                console.error('Hibás', error);
            });
    }, []);

    return (
        <div>
            <div className="header">
                <h1>AlbiGo</h1>
                <ul className="topnav">
                    <li><a className="active" href="./index.html">Kezdőlap</a></li>
                    <li><a href="#news">News</a></li>
                    <li><a href="./login.html">Felhasználó</a></li>
                </ul>
            </div>

            <div className="container content">
                <div className="row" id="adsContainer">
                    {hirdetesek.map((hirdetes, index) => (
                        <div className="row justify-content-center mx-auto col-md-8" style={{ paddingBottom: "20px", paddingTop: "10px" }} key={index}>
                            <Card id={hirdetes.id} />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
